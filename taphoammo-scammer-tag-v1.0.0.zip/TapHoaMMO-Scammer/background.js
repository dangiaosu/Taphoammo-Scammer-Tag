// Danh sách các URL API từ Google Apps Script
const API_URLS = [
"https://script.google.com/macros/s/AKfycbzkombpu36LJFkYZDUX0xT8Pq6onfY1te8v6CblAzu5WbC2XNYaVR5PxY0xfd4-HACukQ/exec",
"https://script.google.com/macros/s/AKfycbz3Ub5Ex7VOJglxQ_QbFfMGghhZOC3lkszt68kvd_fbEz5HjadxU4aqpYC0HJr6SZ7l_Q/exec",
"https://script.google.com/macros/s/AKfycbzRP_gOkem5OM-Ql7yx-9dY94i8I14uLzeKf4MGO9KLT22KSWUZqsURroEUvFvzvHSBsQ/exec",
"https://script.google.com/macros/s/AKfycbyjcUF0yY6HkTqgeQ_qA-RkWszxsJpHWLDEbqlz85Ot2B4uJKU_LyQAyxh4R0Rb869oWA/exec",
"https://script.google.com/macros/s/AKfycbxeZDCiSCCJ5QljOIIzHcTcjqWfq37oAZ0NZxK12xphKLXlSSgvHVHjDyOB6XO9be0L_g/exec",
"https://script.google.com/macros/s/AKfycbyHfM6kAKnQgh75zi0af7AeYq3GATUpn4tFRmESVxzvZCLeGrU5HC29dX51VCfNtzViaQ/exec",
"https://script.google.com/macros/s/AKfycbxxLBZngxrd4vus4QBS1cbanBJSHyEZDqMzCmqRyhbU5xA9giLXw2qcaE3azaDbVmOitQ/exec"
];

async function fetchScammerList() {
  chrome.storage.local.get(['lastUpdated', 'scammerList'], async (result) => {
    const lastUpdated = result.lastUpdated || 0;
    const now = Date.now();
    const twoHours = 2 * 60 * 60 * 1000; // 2 tiếng

    if (now - lastUpdated > twoHours || !result.scammerList) {
      let retries = 3;
      while (retries > 0) {
        try {
          // Chọn ngẫu nhiên một URL API
          const randomApiUrl = API_URLS[Math.floor(Math.random() * API_URLS.length)];
          const response = await fetch(randomApiUrl);
          const scammerList = await response.json();

          if (!Array.isArray(scammerList) || !scammerList.every(item => item.username && typeof item.reason === 'string')) {
            console.error("Dữ liệu không đúng định dạng:", scammerList);
            return;
          }

          chrome.storage.local.set(
            { scammerList: scammerList, lastUpdated: now },
            () => {
              console.log("Danh sách scammer đã được lưu:", scammerList);
            }
          );
          break; // Thoát vòng lặp nếu thành công
        } catch (error) {
          console.error("Lỗi khi lấy danh sách scammer:", error);
          retries--;
          if (retries === 0) {
            console.error("Hết số lần thử, không thể lấy danh sách scammer");
            return;
          }
          await new Promise(resolve => setTimeout(resolve, 5000)); // Chờ 5 giây trước khi thử lại
        }
      }
    } else {
      console.log("Dữ liệu còn mới, không cần gọi API");
    }
  });
}

fetchScammerList();
setInterval(fetchScammerList, 60 * 60 * 1000);