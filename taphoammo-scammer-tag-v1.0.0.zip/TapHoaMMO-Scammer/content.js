console.log('content.js đang chạy'); // Debug để kiểm tra script có chạy không

// Hàm xử lý hiển thị tag Scammer
function addScammerTags() {
  chrome.storage.local.get(['scammerList'], (result) => {
    const scammerList = result.scammerList || [];
    console.log('Danh sách scammer từ Chrome Storage:', scammerList); // Debug

    // Chuyển danh sách thành Set để kiểm tra nhanh hơn
    const scammerSet = new Set(scammerList.map(name => name.trim().toLowerCase()));
    const url = window.location.href;

    // Trang tìm kiếm và danh mục: 
    // - Tìm kiếm: https://taphoammo.net/danh-muc/none?q=&t=&keywork=discord
    // - Danh mục: https://taphoammo.net/danh-muc/tai-khoan?q=cc938237-d4b0-4592-853f-fd27d2aea7c2,&t=&sort=sortPoint&page=2
    if (url.includes('/danh-muc/')) {
      const productItems = document.querySelectorAll('.product-card__features-list');
      productItems.forEach(item => {
        const sellerElement = item.querySelector('a');
        if (sellerElement) {
          const sellerName = sellerElement.textContent.trim().toLowerCase();
          console.log('Người bán (trang danh mục/tìm kiếm):', sellerName); // Debug
          if (scammerSet.has(sellerName) && !sellerElement.querySelector('.scammer-tag')) {
            const tag = document.createElement('span');
            tag.className = 'scammer-tag';
            tag.textContent = 'Scammer';
            sellerElement.appendChild(tag);
          }
        }
      });
    }

    // Trang thông tin người bán: https://taphoammo.net/thong-tin/thieunguyen
    else if (url.includes('/thong-tin/')) {
      const sellerNameElement = document.querySelector('.card-body h4');
      if (sellerNameElement) {
        const sellerName = sellerNameElement.textContent.replace('@', '').trim().toLowerCase();
        console.log('Người bán (trang thông tin):', sellerName); // Debug
        if (scammerSet.has(sellerName) && !sellerNameElement.querySelector('.scammer-tag')) {
          const tag = document.createElement('span');
          tag.className = 'scammer-tag';
          tag.textContent = 'Scammer';
          sellerNameElement.appendChild(tag);
        }
      }
    }

    // Trang gian hàng: https://taphoammo.net/gian-hang/tai-khoan-discord-token-a-ngam-tren-7-day_229943
    else if (url.includes('/gian-hang/')) {
      const sellerNameElement = document.querySelector('.product__meta-availability a');
      if (sellerNameElement) {
        const sellerName = sellerNameElement.textContent.trim().toLowerCase();
        console.log('Người bán (trang gian hàng):', sellerName); // Debug
        if (scammerSet.has(sellerName) && !sellerNameElement.querySelector('.scammer-tag')) {
          const tag = document.createElement('span');
          tag.className = 'scammer-tag';
          tag.textContent = 'Scammer';
          sellerNameElement.appendChild(tag);
        }
      }
    }
  });
}

// Chạy lần đầu
addScammerTags();

// Retry nếu nội dung chưa tải xong
let retryCount = 0;
const maxRetries = 10;
const retryInterval = setInterval(() => {
  if (document.querySelector('.product-card__features-list') || document.querySelector('.card-body h4') || document.querySelector('.product__meta-availability')) {
    console.log('Nội dung đã tải, chạy lại addScammerTags'); // Debug
    addScammerTags();
    clearInterval(retryInterval);
  } else if (retryCount >= maxRetries) {
    console.log('Hết số lần thử, không tìm thấy nội dung'); // Debug
    clearInterval(retryInterval);
  }
  retryCount++;
}, 1000);

// Sử dụng MutationObserver để phát hiện thay đổi trong DOM
const observer = new MutationObserver((mutations) => {
  mutations.forEach(() => {
    console.log('DOM thay đổi, chạy lại addScammerTags'); // Debug
    addScammerTags();
  });
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});